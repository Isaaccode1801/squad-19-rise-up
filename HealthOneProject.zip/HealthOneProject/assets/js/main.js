/**
* Template Name: Medicio
* Template URL: https://bootstrapmade.com/medicio-free-bootstrap-theme/
* Updated: Aug 07 2024 with Bootstrap v5.3.3
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/

// Garante que todo o script só rode depois que o HTML da página estiver pronto.
document.addEventListener('DOMContentLoaded', () => {
  "use strict";

  // =========================================================================
  //         CÓDIGO PARA ABRIR/FECHAR A SIDEBAR
  // =========================================================================
  const toggleBtn = document.getElementById('toggle-sidebar-btn');
  const body = document.body;

  if (toggleBtn && body) {
    toggleBtn.addEventListener('click', () => {
      // Adiciona ou remove a classe 'sidebar-fechada' do <body>
      body.classList.toggle('sidebar-fechada');
    });
  }

  // =========================================================================
  //         RESTANTE DO CÓDIGO DO TEMPLATE "MEDICIO"
  // =========================================================================

  /**
   * Apply .scrolled class to the body as the page is scrolled down
   */
  function toggleScrolled() {
    const selectBody = document.querySelector('body');
    const selectHeader = document.querySelector('#header');

    // Adiciona uma verificação para evitar erros se o #header não existir na página
    if (!selectHeader) return;

    if (!selectHeader.classList.contains('scroll-up-sticky') && !selectHeader.classList.contains('sticky-top') && !selectHeader.classList.contains('fixed-top')) return;
    window.scrollY > 100 ? selectBody.classList.add('scrolled') : selectBody.classList.remove('scrolled');
  }
  document.addEventListener('scroll', toggleScrolled);
  window.addEventListener('load', toggleScrolled);

  /**
   * Mobile nav toggle
   */
  const mobileNavToggleBtn = document.querySelector('.mobile-nav-toggle');
  if (mobileNavToggleBtn) {
    function mobileNavToogle() {
      document.querySelector('body').classList.toggle('mobile-nav-active');
      mobileNavToggleBtn.classList.toggle('bi-list');
      mobileNavToggleBtn.classList.toggle('bi-x');
    }
    mobileNavToggleBtn.addEventListener('click', mobileNavToogle);
  }

  /**
   * Hide mobile nav on same-page/hash links
   */
  document.querySelectorAll('#navmenu a').forEach(navmenu => {
    navmenu.addEventListener('click', () => {
      if (document.querySelector('.mobile-nav-active')) {
        // Re-chama a função de toggle para fechar o menu
        if (mobileNavToggleBtn) mobileNavToogle();
      }
    });
  });

  /**
   * Toggle mobile nav dropdowns
   */
  document.querySelectorAll('.navmenu .toggle-dropdown').forEach(navmenu => {
    navmenu.addEventListener('click', function(e) {
      e.preventDefault();
      this.parentNode.classList.toggle('active');
      this.parentNode.nextElementSibling.classList.toggle('dropdown-active');
      e.stopImmediatePropagation();
    });
  });

  /**
   * Preloader
   */
  const preloader = document.querySelector('#preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      preloader.remove();
    });
  }

  /**
   * Scroll top button
   */
  const scrollTop = document.querySelector('.scroll-top');
  if (scrollTop) {
    function toggleScrollTop() {
      window.scrollY > 100 ? scrollTop.classList.add('active') : scrollTop.classList.remove('active');
    }
    scrollTop.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
    window.addEventListener('load', toggleScrollTop);
    document.addEventListener('scroll', toggleScrollTop);
  }

  /**
   * Animation on scroll function and init
   */
  function aosInit() {
    if (typeof AOS !== 'undefined') {
      AOS.init({
        duration: 600,
        easing: 'ease-in-out',
        once: true,
        mirror: false
      });
    }
  }
  window.addEventListener('load', aosInit);

  /**
   * Initiate glightbox
   */
  if (typeof GLightbox !== 'undefined') {
    const glightbox = GLightbox({
      selector: '.glightbox'
    });
  }

  /**
   * Init swiper sliders
   */
  function initSwiper() {
    if (typeof Swiper === 'undefined') return;
    document.querySelectorAll(".init-swiper").forEach(function(swiperElement) {
      let config = JSON.parse(
        swiperElement.querySelector(".swiper-config").innerHTML.trim()
      );
      new Swiper(swiperElement, config);
    });
  }
  window.addEventListener("load", initSwiper);

  /**
   * Frequently Asked Questions Toggle
   */
  document.querySelectorAll('.faq-item h3, .faq-item .faq-toggle').forEach((faqItem) => {
    faqItem.addEventListener('click', () => {
      faqItem.parentNode.classList.toggle('faq-active');
    });
  });

  /**
   * Correct scrolling position upon page load for URLs containing hash links.
   */
  window.addEventListener('load', function(e) {
    if (window.location.hash) {
      const section = document.querySelector(window.location.hash);
      if (section) {
        setTimeout(() => {
          const scrollMarginTop = getComputedStyle(section).scrollMarginTop;
          window.scrollTo({
            top: section.offsetTop - parseInt(scrollMarginTop),
            behavior: 'smooth'
          });
        }, 100);
      }
    }
  });

  /**
   * Navmenu Scrollspy
   */
  const navmenulinks = document.querySelectorAll('.navmenu a');
  if (navmenulinks.length > 0) {
    function navmenuScrollspy() {
      navmenulinks.forEach(navmenulink => {
        if (!navmenulink.hash) return;
        const section = document.querySelector(navmenulink.hash);
        if (!section) return;
        const position = window.scrollY + 200;
        if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
          document.querySelectorAll('.navmenu a.active').forEach(link => link.classList.remove('active'));
          navmenulink.classList.add('active');
        } else {
          navmenulink.classList.remove('active');
        }
      })
    }
    window.addEventListener('load', navmenuScrollspy);
    document.addEventListener('scroll', navmenuScrollspy);
  }

//Botão de Acessibilidade  
const btn = document.getElementById("btnAcessibilidade");
  const menu = document.getElementById("menuAcessibilidade");

  // Alternar visibilidade do menu
  btn.addEventListener("click", () => {
    menu.style.display = menu.style.display === "flex" ? "none" : "flex";
  });

  // Fechar se clicar fora
  document.addEventListener("click", (e) => {
    if (!menu.contains(e.target) && !btn.contains(e.target)) {
      menu.style.display = "none";
    }
  });

  // Funções de acessibilidade
  const corpo = document.body;

// Função para salvar estado no localStorage
function salvarPreferencia(chave, valor) {
  localStorage.setItem(chave, JSON.stringify(valor));
}

// Função para carregar estado salvo
function carregarPreferencia(chave) {
  const valor = localStorage.getItem(chave);
  return valor ? JSON.parse(valor) : false;
}

// ======== MODO ESCURO ========
const modoEscuroBtn = document.getElementById("modoEscuro");
let modoEscuroAtivo = carregarPreferencia("modoEscuro");

if (modoEscuroAtivo) document.body.classList.add("modo-escuro");

modoEscuroBtn.addEventListener("click", () => {
  modoEscuroAtivo = !modoEscuroAtivo;
  document.body.classList.toggle("modo-escuro", modoEscuroAtivo);
  salvarPreferencia("modoEscuro", modoEscuroAtivo);
});

// ======== MODO DALTÔNICO ========
const modoDaltonicoBtn = document.getElementById("modoDaltonico");
let modoDaltonicoAtivo = carregarPreferencia("modoDaltonico");

if (modoDaltonicoAtivo) document.body.classList.add("modo-daltonico");

modoDaltonicoBtn.addEventListener("click", () => {
  modoDaltonicoAtivo = !modoDaltonicoAtivo;
  document.body.classList.toggle("modo-daltonico", modoDaltonicoAtivo);
  salvarPreferencia("modoDaltonico", modoDaltonicoAtivo);
});

// ======== CONTROLE DE FONTE (ZOOM) ========

// Elementos
const aumentarFonteContainer = document.getElementById("aumentarFonteContainer");
const controlesFonte = document.getElementById("controlesFonte");
const btnMais = document.getElementById("aumentarFonte");
const btnMenos = document.getElementById("diminuirFonte");
const valorFonte = document.getElementById("tamanhoFonteValor");

// Estado inicial (carrega o último valor salvo)
let zoomPagina = carregarPreferencia("zoomPagina") || 100;

// Aplica o zoom salvo ao carregar
document.body.style.zoom = zoomPagina + "%";
if (valorFonte) valorFonte.textContent = `${zoomPagina}%`;

// Mostra/oculta os controles ao clicar no container
if (aumentarFonteContainer && controlesFonte) {
  aumentarFonteContainer.addEventListener("click", (e) => {
    e.stopPropagation();
    controlesFonte.classList.toggle("visivel");
  });
}

// Função para aplicar o zoom e salvar
function aplicarZoom() {
  document.body.style.zoom = zoomPagina + "%";
  if (valorFonte) valorFonte.textContent = `${zoomPagina}%`;
  salvarPreferencia("zoomPagina", zoomPagina);
}

// Botão ➕
if (btnMais) {
  btnMais.addEventListener("click", (e) => {
    e.stopPropagation();
    if (zoomPagina < 180) {
      zoomPagina += 10;
      aplicarZoom();
    }
  });
}

// Botão ➖
if (btnMenos) {
  btnMenos.addEventListener("click", (e) => {
    e.stopPropagation();
    if (zoomPagina > 80) {
      zoomPagina -= 10;
      aplicarZoom();
    }
  });
}

// ======== LEITOR DE TEXTO ========
let leitorAtivo = carregarPreferencia("leitorTexto");

document.getElementById("leitorTexto").addEventListener("click", () => {
  leitorAtivo = !leitorAtivo;
  salvarPreferencia("leitorTexto", leitorAtivo);
  alert(leitorAtivo ? "Leitor de texto ativado." : "Leitor de texto desativado.");
});

document.addEventListener("mouseover", (e) => {
  if (leitorAtivo && e.target.textContent.trim().length > 0) {
    const texto = e.target.textContent.trim();
    const fala = new SpeechSynthesisUtterance(texto);
    fala.lang = "pt-BR";
    speechSynthesis.cancel();
    speechSynthesis.speak(fala);
  }
});


}); // FIM do único document.addEventListener('DOMContentLoaded')

